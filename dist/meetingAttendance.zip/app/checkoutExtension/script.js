let checkOutBtn = document.querySelector(".check-out-btn");
let meetingStatus = document.querySelector(".status");

let meeting_title = document.querySelector(".title-value");
let meeting_time = document.querySelector(".time-value");
let meeting_venue = document.querySelector(".venue-value");
let check_In_Time = document.querySelector(".checkIn-time-value");
let Check_Out_Time = document.querySelector(".checkOut-time-value");

let pendingProgressCircle = document.querySelector(".progress-pending");
let activeProgressCircle = document.querySelector(".progress-active");
let successProgressCircle = document.querySelector(".progress-success");

let i_banner_content_row1 = document.querySelector("#i-banner-content-row1");
let i_banner_content_row2 = document.querySelector("#i-banner-content-row2");

let toastVisible = false;
let distance_restriction_flag = "attendanceforcrmmeetings__Distance_Restriction_Flag";
let distance_value = "attendanceforcrmmeetings__Distance";
let time_restriction_flag = "attendanceforcrmmeetings__TimeRestrictionOption";
let existingDistanceValue, ExistingTimeRestrictionFlag;

let detailsRow = document.querySelectorAll(".detail-row");
detailsRow = [...detailsRow];
let stageText = document.querySelectorAll(".txt");
stageText = [...stageText];
let chinese, is_English;

function showLoader() {
    const loader = document.getElementById("loader");
    if (loader) loader.style.display = "flex";
    const content = document.querySelector(".wrapper");
   
    if (content) content.style.visibility = "hidden"; // hide content
}

function hideLoader() {
    const content = document.querySelector(".wrapper");
    if (content) content.style.visibility = "visible";
    setTimeout(() => {
        document.getElementById("loader").style.display = "none";
    }, 3000); // matches transition duration
}

function dynamicContent(statusContent, btnContent, langObject, stage, status) {
    checkOutBtn.disabled = false;
    checkOutBtn.style.cursor = "pointer";

    meetingStatus.id = statusContent;
    meetingStatus.innerHTML = langObject[statusContent];

    checkOutBtn.id = btnContent;
    checkOutBtn.textContent = langObject[btnContent];

    meetingStatus.classList.add(status);
    checkOutBtn.classList.add(status);

    if (stage === "Check-out-success") {
        activeProgressCircle.classList.add("success");
        pendingProgressCircle.classList.add("success");
        successProgressCircle.classList.add("success");
    } else if (stage === "VISITED" && stage != "Check-out-success") {
        pendingProgressCircle.classList.add("success");
        activeProgressCircle.classList.add("success");
        successProgressCircle.classList.add("pending");
    } else {
        activeProgressCircle.classList.add("pending");
        pendingProgressCircle.classList.add("pending");
        successProgressCircle.classList.add("pending");
    }
}

function calculateDistance(currentLocation, targetLocation) {
    // console.log(currentLocation);
    // console.log(targetLocation);
    
    let lat1 = chinese ? currentLocation.lat : currentLocation.coords.latitude;
    let lon1 = chinese ? currentLocation.lng : currentLocation.coords.longitude;
    // targetLocation = JSON.parse(targetLocation);

    // let lat2 = targetLocation.latitude;
    // let lon2 = targetLocation.longitude;

    let lat2 = targetLocation.lat;
    let lon2 = chinese ? targetLocation.lng : targetLocation.lon;

    const R = 6371e3; // meters
    const DEG_TO_RAD = Math.PI / 180;

    const lat1Rad = lat1 * DEG_TO_RAD;
    const lat2Rad = lat2 * DEG_TO_RAD;
    const deltaLat = (lat2 - lat1) * DEG_TO_RAD;
    const deltaLon = (lon2 - lon1) * DEG_TO_RAD;

    const sinDeltaLat = Math.sin(deltaLat / 2);
    const sinDeltaLon = Math.sin(deltaLon / 2);

    const a = sinDeltaLat * sinDeltaLat +
        Math.cos(lat1Rad) * Math.cos(lat2Rad) *
        sinDeltaLon * sinDeltaLon;

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}
let meetingDetails, currentUser, orgDetails, locale, locale_code, langObj, checkInStatus, checkOutTime, checkInTime, givenLocation, endTime, baiduMap, d, currentStateOfDistanceRestriction;

// Page Load
ZOHO.embeddedApp.on("PageLoad", async function (data) {
    // showLoader();
    // await new Promise(resolve => requestAnimationFrame(resolve));
    // checkOutBtn.disabled = true;
    // checkOutBtn.style.cursor = "not-allowed";
    // try {
        
    //     // await new Promise(r => setTimeout(r, 300));
        
    //     currentUser = await ZOHO.CRM.CONFIG.getCurrentUser();

    //     let distanceFlag = await getVariables(distance_restriction_flag);
    //     let configured_distance = await getVariables(distance_value);
    //     let ExistingTimeRestriction = await getVariables(time_restriction_flag);
    //     ExistingTimeRestrictionFlag = ExistingTimeRestriction.details.output;
    //     existingDistanceValue = configured_distance.details.output;

    //     currentStateOfDistanceRestriction = distanceFlag.details.output;

    //     locale = await currentUser.users[0].locale;
    //     locale_code = await currentUser.users[0].locale_code;

    //     if (locale.startsWith("en")) {
    //         let res = await fetch("../translations/en.json");
    //         langObj = await res.json();
    //     }
    //     else if (locale.startsWith("zh")) {
    //         let res = await fetch("../translations/zh.json");
    //         langObj = await res.json();
    //     }
    //     if (langObj) {
    //         stageText.forEach(stage => {
    //             stage.textContent = langObj[stage.id];
    //         });
    //         detailsRow.forEach(row => {
    //             let firstTd = row.querySelector("td:first-child");
    //             if (firstTd) {
    //                 firstTd.textContent = langObj[firstTd.id];
    //             }
    //         });
    //     }
    //     i_banner_content_row1.textContent = langObj[i_banner_content_row1.id];
    //     i_banner_content_row2.textContent = langObj[i_banner_content_row2.id];

    //     // 1. Get Meeting Record Details
    //     let meetingRecordConfig = {
    //         Entity: "Events",
    //         approved: "both",
    //         RecordID: data.EntityId[0],
    //     };

    //     meetingDetails = await ZOHO.CRM.API.getRecord(meetingRecordConfig);
    //     orgDetails = await ZOHO.CRM.CONFIG.getOrgInfo();

    //     checkInStatus = meetingDetails.data[0].Check_In_Status;
    //     checkOutTime = meetingDetails.data[0].attendanceforcrmmeetings__Checkout_Time;
    //     checkInTime = meetingDetails.data[0].Check_In_Time;

    //     givenLocation = meetingDetails.data[0].Venue;
    //     endTime = meetingDetails.data[0].End_DateTime;

    //     meeting_title.textContent = meetingDetails.data[0].Event_Title;
    //     meeting_time.textContent = formatDateRange(getTimeToDisplay(meetingDetails.data[0].Start_DateTime, orgDetails.org[0].time_zone), getTimeToDisplay(meetingDetails.data[0].End_DateTime, orgDetails.org[0].time_zone));
    //     meeting_venue.textContent = givenLocation ? givenLocation : langObj["loc-not-specified"];
    //     check_In_Time.textContent = checkInTime ? getTimeToDisplay(meetingDetails.data[0].Check_In_Time, orgDetails.org[0].time_zone) : langObj["yet-to-check-in"];
    //     Check_Out_Time.textContent = checkOutTime ? getTimeToDisplay(checkOutTime, orgDetails.org[0].time_zone) : langObj["yet-to-check-out"];

    //     if (checkInStatus === "VISITED" && !checkOutTime) {
    //         activeProgressCircle.style.setProperty("--after-animation", "pulse 1.5s infinite");
    //         activeProgressCircle.style.setProperty("--after-border", "1px solid #2563eb");
    //         dynamicContent("actual-status-check-out-pending", "button-pending", langObj, "VISITED", "active");
    //     }
    //     else if (checkInStatus === "PLANNED") {
    //         dynamicContent("actual-status-check-in-pending", "button-pending", langObj, "PLANNED", "pending");
    //     }
    //     else if (checkOutTime != null) {
    //         checkOutBtn.classList.add("out");
    //         dynamicContent("actual-status-already-done", "button-success", langObj, "Check-out-success", "success");
    //     }
    //     // hideLoader();
    // } catch (error) {
    //     console.log(error);
    // }
    // finally{
       
    //     hideLoader();
    // }

    showLoader();
// await new Promise(resolve => requestAnimationFrame(resolve));
checkOutBtn.disabled = true;
checkOutBtn.style.cursor = "not-allowed";

try {
    // ✅ Run all independent API calls in parallel
    [
        currentUser,
        distanceFlag,
        configured_distance,
        ExistingTimeRestriction
    ] = await Promise.all([
        ZOHO.CRM.CONFIG.getCurrentUser(),
        getVariables(distance_restriction_flag),
        getVariables(distance_value),
        getVariables(time_restriction_flag)
    ]);

    // ✅ No need for await on plain object property access
    ExistingTimeRestrictionFlag = ExistingTimeRestriction.details.output;
    existingDistanceValue = configured_distance.details.output;
    currentStateOfDistanceRestriction = distanceFlag.details.output;
    locale = currentUser.users[0].locale;
    locale_code = currentUser.users[0].locale_code;

    // ✅ Fetch translation in parallel with CRM calls below
    const langFetchPromise = (async () => {
        if (locale.startsWith("en")) {
            const res = await fetch("../translations/en.json");
            return res.json();
        } else if (locale.startsWith("zh")) {
            const res = await fetch("../translations/zh.json");
            return res.json();
        }
        return null;
    })();

    // ✅ Run meeting + org API calls in parallel with translation fetch
    const [TRANSLATIONS, meetingRes, orgRes] = await Promise.all([
        langFetchPromise,
        ZOHO.CRM.API.getRecord({
            Entity: "Events",
            approved: "both",
            RecordID: data.EntityId[0],
        }),
        ZOHO.CRM.CONFIG.getOrgInfo()
    ]);
langObj = TRANSLATIONS;
    // ✅ Apply translations if available
    if (langObj) {
        stageText.forEach(stage => {
            stage.textContent = langObj[stage.id];
        });
        detailsRow.forEach(row => {
            const firstTd = row.querySelector("td:first-child");
            if (firstTd) firstTd.textContent = langObj[firstTd.id];
        });
        i_banner_content_row1.textContent = langObj[i_banner_content_row1.id];
        i_banner_content_row2.textContent = langObj[i_banner_content_row2.id];
    }
    // ✅ Destructure once — avoids repeated deep access
    meetingDetails = meetingRes;
    orgDetails = orgRes;
    const meeting = meetingRes.data[0];
    const tz = orgRes.org[0].time_zone;
    

    checkInStatus  = meeting.Check_In_Status;
    checkOutTime   = meeting.attendanceforcrmmeetings__Checkout_Time;
    checkInTime    = meeting.Check_In_Time;
    givenLocation  = meeting.Venue;
    endTime        = meeting.End_DateTime;

    meeting_title.textContent  = meeting.Event_Title;
    
    meeting_time.textContent   = formatDateRange(getTimeToDisplay(meeting.Start_DateTime, tz),getTimeToDisplay(meeting.End_DateTime, tz));
    
    meeting_venue.textContent  = givenLocation ?? langObj?.["loc-not-specified"];
    check_In_Time.textContent  = checkInTime
        ? getTimeToDisplay(checkInTime, tz)
        : langObj?.["yet-to-check-in"];
    Check_Out_Time.textContent = checkOutTime
        ? getTimeToDisplay(checkOutTime, tz)
        : langObj?.["yet-to-check-out"];

    // ✅ Status logic unchanged, just cleaner grouping
    if (checkInStatus === "VISITED" && !checkOutTime) {
        activeProgressCircle.style.setProperty("--after-animation", "pulse 1.5s infinite");
        activeProgressCircle.style.setProperty("--after-border", "1px solid #2563eb");
        dynamicContent("actual-status-check-out-pending", "button-pending", langObj, "VISITED", "active");
    } else if (checkInStatus === "PLANNED") {
        dynamicContent("actual-status-check-in-pending", "button-pending", langObj, "PLANNED", "pending");
    } else if (checkOutTime != null) {
        checkOutBtn.classList.add("out");
        dynamicContent("actual-status-already-done", "button-success", langObj, "Check-out-success", "success");
    }    

} catch (error) {
    console.error("Initialization failed:", error);
    // e.g.: showErrorBanner(langObj?.["generic-error"] ?? "Something went wrong. Please try again.");
} finally {
    // document.body.getBoundingClientRect(); // flush layout

    // await new Promise(resolve => {
    //     requestAnimationFrame(() => {
    //         requestAnimationFrame(() => {
    //             // Final safety net: defer until browser is truly idle after paint
    //             if ("requestIdleCallback" in window) {
    //                 requestIdleCallback(resolve, { timeout: 500 });
    //             } else {
    //                 setTimeout(resolve, 1000); // minimal fallback, not 1700ms
    //             }
    //         });
    //     });
    // });

    // await new Promise(resolve => requestAnimationFrame(resolve));
    // await new Promise(resolve => requestAnimationFrame(resolve));

    // setTimeout(()=>{hideLoader();}, 3000);
    // checkOutBtn.disabled = false;
    // checkOutBtn.style.cursor = "pointer";
}
    // 2. Detect Platform - from Where Button is Accessed.
    // let detectPlatform = function detectPlatform() {
    //   const ua = navigator.userAgent.toLowerCase();
    //   if (ua.includes("android") || ua.includes("iphone") || ua.includes("ipad") || ua.includes("zoho") ) {
    //     return "mobile";
    //   } else if (/ZohoCRM_Desktop|Electron/i.test(ua)) {
    //     return "desktop";
    //   } else {
    //     return "web";
    //   }
    // };
    // let platform = detectPlatform();

    // if (platform === "mobile") {
    // 3. Check Checked In Or Not
    if (checkInStatus === "VISITED" && !checkOutTime) {

        checkOutBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            const currentDate = new Date();
            const endingTime = new Date(endTime);

            if (ExistingTimeRestrictionFlag == "true") {
                if (currentDate > endingTime) {
                    await mainFunction(currentDate, endingTime, data);
                }
                else {
                    showToast(langObj["toast-meeting-not-ended"], "#eed202");
                    btnBackToAction();
                }
            }
            else {
                await mainFunction(currentDate, endingTime, data);
            }

        });
    }
    else if (checkInStatus === "PLANNED") {
        meetingStatus.classList.add("error");
        showToast(langObj["toast-checkin-warning"], "#eed202");
        showError();
        return;
    } else if (checkOutTime != null) {
        showToast(langObj["toast-already-checked-out"], "red");
        meetingStatus.classList.add("success");
        checkOutBtn.classList.add("out");
        successProgressCircle.classList.add("success");
        return;
    }
    else {
        showToast(langObj["toast-error-contact-support"], "red");
        btnBackToAction();
        return;
    }
    // } else {
    //   showToast("This Button Action is allowed only in mobile app", "red");
    //   showError();
    //   return;
    // }
});

// HERE - Map api for both forward and reverse geocode
// HERE Maps - Reverse Geocoding
async function reverseGeocodeHERE(lat, lng) {
    try {
        const response = await fetch(
            `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${lat},${lng}&apiKey=YOUR_HERE_API_KEY`
        );
        const data = await response.json();

        if (data.items && data.items.length > 0) {
            return data.items[0];
        } else {
            throw new Error('No results found');
        }
    } catch (error) {
        console.error('HERE reverse geocoding failed:', error.message);
        throw error;
    }
}

// Baidu - Reverse Geocoding
async function reverseGeocodeBaidu(point) {
    return new Promise((resolve, reject) => {
        const geocoder = new BMapGL.Geocoder();

        geocoder.getLocation(point, function(result) {
            if (result) {
                resolve(result);
            } else {
                reject(new Error('Baidu reverse geocoding failed'));
            }
        });
    });
}

// HERE Maps - Forward Geocoding
async function forwardGeocodeHERE(address) {
    try {
        const response = await fetch(
            `https://geocode.search.hereapi.com/v1/geocode?q=${encodeURIComponent(address)}&apiKey=YOUR_HERE_API_KEY`
        );
        const data = await response.json();

        if (data.items && data.items.length > 0) {
            const { lat, lon } = data.items[0].position;
            return { lat, lon };
        } else {
            throw new Error('No results found');
        }
    } catch (error) {
        console.error('HERE forward geocoding failed:', error.message);
        throw error;
    }
}

// Baidu - Forward Geocoding
async function forwardGeocodeBaidu(address) {
    return new Promise((resolve, reject) => {
        const geocoder = new BMapGL.Geocoder();

        geocoder.getPoint(address, function(point) {
            if (point) {
                resolve(point);
            } else {
                reject(new Error('Baidu forward geocoding failed'));
            }
        }, 'China');
    });
}

async function mainFunction(currentDate, endingTime, data) {
    const originalText = checkOutBtn.innerHTML;
    checkOutBtn.id = "button-in-progress";
    checkOutBtn.textContent = langObj["button-in-progress"];
    checkOutBtn.disabled = true;

    let formattedCheckOutTime = getCurrentTimeInIST(currentDate, orgDetails.org[0].time_zone);

    let durationTime = function durationsTime() {
        const inTime = new Date(checkInTime);
        const outTime = new Date(currentDate);

        const duration = outTime - inTime;

        const inSeconds = duration / 1000;

        const inMinutes = Math.floor(inSeconds / 60);
        const hours = Math.floor(duration / (1000 * 60 * 60));
        const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

        if (inMinutes >= 60) {
            return `${hours} hours ${minutes} minutes`;
        } else if (inMinutes > 0 && inMinutes < 60) {
            return `${inMinutes} minutes`;
        }
        else {
            return `${inSeconds} seconds`;
        }
    }

    let duration = durationTime();

    function getPointWrapper(address) {
        return new Promise((resolve, reject) => {
            try {
                const myGeo = new BMapGL.Geocoder();
                myGeo.getPoint(address, function (point) {
                    if (point) {
                        resolve(point);
                    } else {
                        reject(point);
                    }
                });
            } catch (err) {
                reject(err);
            }
        });
    }

    async function geoCodeTheLocation(loc) {
        try {
            let point = await getPointWrapper(loc);
            return point;
        } catch (err) {
            return err;
        }
    }

    // i. Check the Location Language

    let geoCode_OfGivenLocation, mapProvider;

    if (givenLocation) {
        const sanitized = sanitizeInput(givenLocation);
        chinese = isChinese(sanitized);
        is_English = isEnglish(sanitized);

        if (chinese) {
            mapProvider = "BAIDU";
            geoCode_OfGivenLocation = await geoCodeTheLocation(givenLocation);
            // let re = await reverseLocBaiduResponse(geoCode_OfGivenLocation.lon, geoCode_OfGivenLocation.lat);
            let validated = validateGeocode(geoCode_OfGivenLocation);
            if (validated.status === "LOW_CONFIDENCE") {
                return { suggestions: geo.matches };
            }
        }
        else if (isEnglish(sanitized)) {
            mapProvider = "BROWSER_NAVIGATION";
            // geoCode_OfGivenLocation = await forwardGeocodeHERE(givenLocation);
            var req_data = {
                "arguments": JSON.stringify({
                    "location": givenLocation
                })
            };
            let func_name = "attendanceforcrmmeetings__getlocation";
            let zohoMapsResponse = await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data);
            // console.log(zohoMapsResponse);
            
            if (zohoMapsResponse.details.output != "") {
                let parsedDATA = JSON.parse(zohoMapsResponse.details.output);
                geoCode_OfGivenLocation = { "lat": parsedDATA.lat, "lon": parsedDATA.lon };
            //     // let re = await reverseLocBaiduResponse(geoCode_OfGivenLocation.lon, geoCode_OfGivenLocation.lat);
            }

        }
    }
    getCoords(mapProvider, formattedCheckOutTime, data, duration, currentUser, geoCode_OfGivenLocation, originalText);
}

async function getCoords(mapProvider, formattedCheckOutTime, data, duration, currentUser, geoCode_OfGivenLocation, originalText) {
    // let originalTextOfButton = originalText;
    if (mapProvider == "BAIDU") {
        try {
            const result = await new Promise((resolve, reject) => {
                const geolocation = new BMapGL.Geolocation();
                geolocation.getCurrentPosition(function(result) {
                    if (this.getStatus() === BMAP_STATUS_SUCCESS) {
                        resolve(result);
                    } else if (this.getStatus() === BMAP_STATUS_TIMEOUT) {
                        reject(new Error(langObj["toast-location-request-timed-out"]));
                    } else if (this.getStatus() === BMAP_STATUS_PERMISSION_DENIED) {
                        reject(new Error(langObj["toast-location-access-denied"]));
                    }
                }, { enableHighAccuracy: true });
            });

            // result is available here — same as before
            var point = result.point;
            initiateCheckoutProcess(point, formattedCheckOutTime, data, duration, currentUser, geoCode_OfGivenLocation);

        } catch (error) {
            console.error('Baidu geolocation failed:', error.message);
            checkOutBtn.innerHTML = originalText;
            showToast(error.message, "red");
            btnBackToAction();
        }

    } else {
        // if (navigator.geolocation) {
        //     navigator.geolocation.getCurrentPosition(async function(position) {
        //         initiateCheckoutProcess(position, formattedCheckOutTime, data, duration, currentUser, geoCode_OfGivenLocation);
        //     });
        // } else {
        //     checkOutBtn.innerHTML = originalText;
        //     showToast(langObj["toast-geolocation-not-supported"], "red");
        //     btnBackToAction();
        // }

        // ----
        if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        async function(position) {
            initiateCheckoutProcess(
                position,
                formattedCheckOutTime,
                data,
                duration,
                currentUser,
                geoCode_OfGivenLocation
            );
        },
        function(error) {
            checkOutBtn.innerHTML = originalText;
            btnBackToAction();

            if (error.code === error.PERMISSION_DENIED) {
                showToast(langObj[ "toast-location-access-denied"], "red");
            } else if (error.code === error.POSITION_UNAVAILABLE) {
                showToast(langObj["toast-location-unavailable"], "red");
            } else if (error.code === error.TIMEOUT) {
                showToast(langObj["toast-location-request-timed-out"], "red");
            } else {
                showToast(langObj["toast-location-unable-toFetch"], "red");
            }
        }
    );
} else {
    checkOutBtn.innerHTML = originalText;
    showToast(langObj["toast-geolocation-not-supported"], "red");
    btnBackToAction();
}
    }
}

async function initiateCheckoutProcess(position, formattedCheckOutTime, data, duration, currentUser, geoCode_OfGivenLocation) {
    try {
        if (currentStateOfDistanceRestriction == "false") {
            await checkOutProcess(position, formattedCheckOutTime, data, duration, currentUser);
        }
        else if (!givenLocation) {
            await checkOutProcess(position, formattedCheckOutTime, data, duration, currentUser);
        }
        else {
            if (geoCode_OfGivenLocation !== null) {
                
                let distance = calculateDistance(position, geoCode_OfGivenLocation);
                if (distance <= (existingDistanceValue) * 1000) {
                    await checkOutProcess(position, formattedCheckOutTime, data, duration, currentUser);
                }
                else {
                    showToast(langObj["toast-location-not-in-boundry"], "red");
                    btnBackToAction();
                }
            }
            else {
                showToast("Unable to Geocode!", "red");
                btnBackToAction();
            }

        }
    } catch (err) {
        showToast(langObj["toast-unexpected-error"], "red");
        btnBackToAction();
    } finally {
        checkOutBtn.disabled = false;
    }
}
async function checkOutProcess(position, formattedCheckOutTime, data, duration, currentUser) {
    // let reverseLocation = await reverseGeocode(position.coords.latitude, position.coords.longitude);
    let reverseLocation;
    if (chinese) {
        reverseLocation = await reverseLocBaiduResponse(position.lng, position.lat);
    }
    else {
        var req_data = {
            "arguments": JSON.stringify({
                "location": {
                    "lat": position.coords.latitude,
                    "lon": position.coords.longitude
                }
            })
        };

        let func_name = "attendanceforcrmmeetings__reversegeocode";
        let zohoMapsResponse = await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data);
        reverseLocation = JSON.parse(zohoMapsResponse.details.output);
    }
    if (reverseLocation !== null) {
        let updateRecord = await updateMeetingRecord(reverseLocation, formattedCheckOutTime, data, position, duration, currentUser);
        meetingStatus.classList.add("success");
        if (updateRecord) {
            successProgressCircle.style.backgroundColor = "#16a34a";
            Check_Out_Time.textContent = getTimeToDisplay(formattedCheckOutTime, orgDetails.org[0].time_zone);

            meetingStatus.id = "actual-status-success";
            meetingStatus.textContent = langObj["actual-status-success"];
            activeProgressCircle.style.setProperty("--after-animation", "");
            activeProgressCircle.style.setProperty("--after-border", "");
            checkOutBtn.classList.add("out");
            showToast(langObj["toast-checkout-success"], "green");
        } else {
            showToast(langObj["toast-details-update-failed"], "red");
            btnBackToAction();
        }
    } else {
        showToast(langObj["toast-reverse-geocode-failed"], "red");
        btnBackToAction()
    }
}

// async function reverseGeocode(lat, lng) {
//     // const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`;

//     // let response = await fetch(url);
//     // if (response.status == 200) {
//     //     let data = await response.json();
//     //     return data;
//     // } else {
//     //     showToast(response.statusText, "red");
//     //     return false;
//     // }
// }

function reverseLocationBaidu(lng, lat) {
    return new Promise((resolve, reject) => {
        try {
            const myGeo = new BMapGL.Geocoder();
            myGeo.getLocation(new BMapGL.Point(lng, lat), function (loc) {
                if (loc) {
                    resolve(loc);
                } else {
                    reject(loc);
                }
            });
        } catch (err) {
            reject(err);
        }
    });
}

async function reverseLocBaiduResponse(lng, lat) {
    try {
        let location = await reverseLocationBaidu(lng, lat);
        return location;
    } catch (err) {
        return err;
    }
}
function formatDateRange(start, end) {
    const [startTime, startDate] = start.split(", ");
    const [endTime, endDate] = end.split(", ");

    if (startDate === endDate) {
        // Same date → merge
        return `${startTime} - ${endTime}, ${startDate}`;
    } else {
        // Different dates → keep both
        return `${startTime}, ${startDate} - ${endTime}, ${endDate}`;
    }
}

async function updateMeetingRecord(location, time, currentRecord, position, durationTime, currentUser) {
    // let locationObjectKeys = Object.keys(location.address ? location.address : location.label);
    // console.log(locationObjectKeys);

    // let keys = locationObjectKeys.slice(0, 3);
    // const matchingKeys = keys.filter((key) =>
    //     key.toLowerCase().startsWith("sub")
    // );
    // let city, subLocality;
    // if (location.address.city) {
    //     city = location.address.city;
    //     subLocality = location.address[matchingKeys[0]];
    // } else {
    //     city = location.address.town;
    //     subLocality = location.address[matchingKeys[0]];
    // }
    let extensionConfig, fullAddress;
    if (chinese) {
        fullAddress = location.address;
        extensionConfig = {
            Entity: "Events",
            APIData: {
                id: currentRecord.EntityId[0],
                attendanceforcrmmeetings__Checkout_City: location.addressComponents.city,
                attendanceforcrmmeetings__Checkout_Country: location.content.address_detail.country,
                attendanceforcrmmeetings__Checkout_State: location.addressComponents.province,
                attendanceforcrmmeetings__Checkout_Address: location.address,
                attendanceforcrmmeetings__Checkout_Latitude: position.lat.toString(),
                attendanceforcrmmeetings__Checkout_Longitude: position.lng.toString(),
                attendanceforcrmmeetings__Checkout_Zipcode: location.address.postcode,
                attendanceforcrmmeetings__Checkout_Time: time.toString(),
                attendanceforcrmmeetings__Check_out_Sub_Locality: location.content.address_detail.town,
                attendanceforcrmmeetings__Meeting_Duration: durationTime,
                attendanceforcrmmeetings__Checkout_By: currentUser.users[0].full_name,
            },
            Trigger: ["workflow"],
        };
    }
    else {
        fullAddress = location.label;
        extensionConfig = {
            Entity: "Events",
            APIData: {
                id: currentRecord.EntityId[0],
                attendanceforcrmmeetings__Checkout_City: location.city,
                attendanceforcrmmeetings__Checkout_Country: location.country,
                attendanceforcrmmeetings__Checkout_State: location.state,
                attendanceforcrmmeetings__Checkout_Address: location.label,
                attendanceforcrmmeetings__Checkout_Latitude: position.coords.latitude.toString(),
                attendanceforcrmmeetings__Checkout_Longitude: position.coords.longitude.toString(),
                attendanceforcrmmeetings__Checkout_Zipcode: location.postal_code,
                attendanceforcrmmeetings__Checkout_Time: time.toString(),
                attendanceforcrmmeetings__Check_out_Sub_Locality: location.address_line2,
                attendanceforcrmmeetings__Meeting_Duration: durationTime,
                attendanceforcrmmeetings__Checkout_By: currentUser.users[0].full_name,
            },
            Trigger: ["workflow"],
        };
    }
    let res = await ZOHO.CRM.API.updateRecord(extensionConfig);
    let notesContent = fullAddress ? "Checked Out @" + fullAddress : "Checked Out at " + time;

    var notesConfig = {
        Entity: "Notes",
        APIData: {
            Parent_Id: currentRecord.EntityId[0],
            Note_Content: notesContent,
            Note_Title: "",
            $se_module: "Events",
        },
        Trigger: ["workflow"],
    };

    let notesRes = await ZOHO.CRM.API.insertRecord(notesConfig);
    if (notesRes.data[0].code === "SUCCESS" && res.data[0].code === "SUCCESS") {
        return true;
    } else return false;
}

function getTimeToDisplay(isoString, locale) {
    const d = new Date(isoString);

    // Force consistent parts (don’t let locale decide the order)
    const options = {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    };

    // Format for given timezone
    const formatter = new Intl.DateTimeFormat("en-US", {
        ...options,
        timeZone: locale
    });

    const parts = formatter.formatToParts(d);

    // Extract parts
    const hour = parts.find(p => p.type === "hour").value;
    const minute = parts.find(p => p.type === "minute").value;
    const day = parts.find(p => p.type === "day").value;
    const month = parts.find(p => p.type === "month").value;
    const year = parts.find(p => p.type === "year").value;    
    const dayPeriod = parts.find(p=>p.type === "dayPeriod").value.toUpperCase();
    
    return `${hour}:${minute} ${langObj[dayPeriod]}, ${day}-${month}-${year}`;
}

function getUTCOffsetFromTimeZone(timeZone, date = new Date()) {
    const f = new Intl.DateTimeFormat("en-US", {
        timeZone,
        hour12: false,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    });

    const parts = f.formatToParts(date).reduce((acc, part) => {
        if (part.type !== "literal") acc[part.type] = part.value;
        return acc;
    }, {});

    // Construct local time in that zone as UTC
    const local = Date.UTC(
        parseInt(parts.year),
        parseInt(parts.month) - 1,
        parseInt(parts.day),
        parseInt(parts.hour),
        parseInt(parts.minute),
        parseInt(parts.second)
    );

    // Difference in minutes
    let diff = (local - date.getTime()) / 60000;
    diff = Math.round(diff);

    const sign = diff >= 0 ? "+" : "-";
    const abs = Math.abs(diff);
    const hours = String(Math.floor(abs / 60)).padStart(2, "0");
    const minutes = String(abs % 60).padStart(2, "0");

    return `${sign}${hours}:${minutes}`;
}

function getCurrentTimeInIST(inp, timeZone) {
    const d = inp ? new Date(inp) : new Date();

    const options = {
        timeZone,
        hour12: false,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    };

    const formatter = new Intl.DateTimeFormat("en-GB", options);
    const parts = formatter.formatToParts(d).reduce((acc, part) => {
        acc[part.type] = part.value;
        return acc;
    }, {});

    const offSet = getUTCOffsetFromTimeZone(timeZone, d);

    return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}${offSet}`;
}

let activeToast = null;

function isChinese(text) {
    return /[\u4e00-\u9fff]/.test(text);
}

function isEnglish(text) {
    return /^[A-Za-z0-9\s,.-]+$/.test(text);
}

function sanitizeInput(text) {
    return text
        .trim()
        .replace(/[^\w\s\u4e00-\u9fff,.-]/g, "");
}

function validateGeocode(result) {
    if (!result || !result.lat || !result.lng) {
        throw new Error("Invalid geocoding result");
    }

    if (result.confidence && result.confidence < 0.7) {
        return { status: "LOW_CONFIDENCE", result };
    }

    return { status: "VALID", result };
}

async function getVariables(fieldName) {
    var req_data = {
        "arguments": JSON.stringify({
            "fieldName": fieldName,
        })
    };
    let func_name = "attendanceforcrmmeetings__getdistancerestrictionflag";
    let variableRes = await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data);
    return variableRes
}

async function updateVariable(fieldValue, fieldAPIName) {
    try {
        var req_data = {
            "arguments": JSON.stringify({
                "value": fieldValue,
                "fieldName": fieldAPIName
            })
        };
        let func_name = "attendanceforcrmmeetings__updatevariable";
        let updateCustomVariable = await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data);
        let res = await JSON.parse(updateCustomVariable.details.output);
        if (res.status_code == 200) {
            return res;
        }
    } catch (error) {
        return error;
    }

}

function showToast(message, color) {
    // Remove previous toast if still visible
    if (activeToast) {
        activeToast.hideToast(); // Toastify provides this method
        activeToast = null;
    }

    // Create new toast and store reference
    activeToast = Toastify({
        text: message,
        duration: 6000,
        gravity: "top",
        position: "center",
        backgroundColor: color,
        stopOnFocus: true,
        color: "black",
    });
    activeToast.showToast();
}

function showError() {
    checkOutBtn.disabled = true;
    checkOutBtn.style.cursor = "not-allowed";
}

function btnBackToAction() {
    checkOutBtn.disabled = false;
    checkOutBtn.style.cursor = "pointer";
    checkOutBtn.textContent = langObj["btn-check-out-now"];
}
function hideLoaderAfterPaint(watchElement) {
    return new Promise(resolve => {
        // Element already has content — just wait for next paint
        if (watchElement.textContent.trim() !== "") {
            requestAnimationFrame(() => {
                hideLoader();
                resolve();
            });
            return;
        }

        // Wait for the element to receive content
        const observer = new MutationObserver(() => {
            observer.disconnect();
            // Content is SET — now wait for browser to actually PAINT it
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    hideLoader();
                    resolve();
                });
            });
        });

        observer.observe(watchElement, {
            childList: true,
            characterData: true,
            subtree: true
        });
    });
}